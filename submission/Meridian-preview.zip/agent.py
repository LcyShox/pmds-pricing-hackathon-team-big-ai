"""Plan production against unit margins and learn sealed-auction prices from fills."""
from collections import defaultdict
from math import ceil, sqrt

from dme_simulator.agents import AssemblyOrder, BaseAgent, Bid, Decision, Listing


# Opening sales estimates for the public hardware market; sales update them.
PRODUCTS = {
    "LAPTOP": (3.75, 475., 760.),
    "CONSOLE": (2.92, 380., 570.),
    "TABLET": (4.38, 213., 310.),
    "PHONE": (8.33, 173., 261.),
    "SMARTWATCH": (5.63, 94., 135.),
}


class MeridianAgent(BaseAgent):
    def __init__(self):
        self.started = False
        self.auction_pos = 0
        self.sale_pos = 0
        self.team = None
        self.last_bids = {}
        self.ratios = {}
        self.quote = {}
        self.demand = {}
        self.prior = {}
        self.price_factor = {}
        self.last_asks = {}
        self.retail = {}
        self.cash_start = 0.
        self.cash_peak = 0.
        self.last_turn = 0
        self.dry = {}
        self.narrow = False
        self.fast_sales = 0.
        self.market_bound = None
        self.market_previous = None
        self.coast = False
        self.recovery = 0

    def _learn(self, s):
        if self.team is None:
            same = [k for k, v in s.public_capital.items()
                    if v == s.capital and s.public_inventories[k] == s.inventory]
            if len(same) == 1:
                self.team = same[0]
        fills = defaultdict(int)
        for tx in s.auction_transactions[self.auction_pos:]:
            if tx.buyer == self.team or (self.team is None and
                    (tx.good, tx.price) in self.last_bids):
                fills[tx.good, tx.price] += tx.quantity
        self.auction_pos = len(s.auction_transactions)
        # A win at the cheap level is an upper bound on the clearing price.
        # Losing every level gives a lower bound. Never pay the top quote on
        # the entire order just to find out which case applies.
        for m, levels in self.quote.items():
            cheap = [ratio for price, ratio, qty in levels if fills[m, price] >= .8 * qty]
            if cheap:
                ratio = min(min(cheap)*.95, self.ratios.get(m, min(cheap))*.96)
            else:
                partial = [ratio for price, ratio, qty in levels if fills[m, price]]
                ratio = min(partial)*1.1 if partial else max(x[1] for x in levels)*1.30
            self.ratios[m] = max(1.015, min(45., ratio))
        for m in self.ratios.keys() - self.quote.keys():
            self.ratios[m] = max(1.02, self.ratios[m] * 0.91)
        units, receipts = defaultdict(int), defaultdict(float)
        for tx in s.sales_transactions[self.sale_pos:]:
            if tx.seller == self.team or (self.team is None and tx.price in self.last_asks.get(tx.good, ())):
                units[tx.good] += tx.quantity
                receipts[tx.good] += tx.quantity * tx.price
        self.sale_pos = len(s.sales_transactions)
        self.fast_sales = .65 * self.fast_sales + .35 * sum(receipts.values())
        for g in self.last_asks:
            n, stock = units[g], s.inventory.get(g, 0)
            if not n and not stock:
                continue
            v = self.demand[g]
            self.demand[g] = max(.45, .76*v + .24*(max(v, 1.25*n) if n and not stock else n))
            self.dry[g] = 0 if n else self.dry.get(g, 0) + 1
            if n:
                previous = self.retail.get(g, receipts[g]/n)
                self.retail[g] = .72*previous + .28*receipts[g]/n
            if self.dry[g] >= 2:
                move = .85
            elif stock > max(2., 1.8*v):
                move = .976
            elif n and stock <= .22*v:
                move = 1.035
            else:
                move = 1.
            self.price_factor[g] = max(.12, min(5., self.price_factor[g]*move))

    def _start(self, s, recipes, lots):
        self.cash_start = self.cash_peak = s.capital
        for r in recipes.values():
            g = r.output_good
            cost = sum(n * lots[m].reserve_price for m,n in r.inputs.items() if m in lots)
            capacity = min((lots[m].quantity if m in lots else 0)/n for m,n in r.inputs.items())
            if g in PRODUCTS:
                v, low, high = PRODUCTS[g]
                if lots.get("CHIP") and lots["CHIP"].quantity >= 75:
                    v *= 5.
            elif g == "WIDGET":
                self.narrow = len(recipes)==1 and cost >= 8 and capacity <= 30
                v, low, high = (max(1,capacity), 97., 100.) if self.narrow else (38.,40.,59.)
            else:
                v = max(1., min(16., capacity / max(2,2*len(recipes))))
                low, high = max(2., 2.7*cost), max(3., 5.*cost)
            self.prior[g] = low, high
            self.demand[g] = v
            self.price_factor[g] = 1.
        self.started = True

    def decide(self, state, goods_config):
        s = state
        if s.turn <= self.last_turn:
            self.__init__()
        self.last_turn = s.turn
        recipes = goods_config.recipes
        lots = {lot.good:lot for lot in s.auction_lots}
        if not recipes:
            return Decision()
        if not self.started:
            self._start(s, recipes, lots)
        self._learn(s)
        crowd = len(s.public_capital) >= 12
        halt_buying = False
        if crowd:
            # A material used once per product is a market-wide unit counter.
            # Last turn's lot minus the increase in raw + embodied stock is
            # an upper bound on sales, even when some of the lot was unsold.
            common = set.intersection(*(set(r.inputs) for r in recipes.values()))
            counter = next((m for m in sorted(common) if m in lots and
                            all(r.inputs[m] == 1 for r in recipes.values())), None)
            if counter:
                units = sum(inv.get(counter,0) + sum(inv.get(g,0) for g in self.prior)
                            for inv in s.public_inventories.values())
                if self.market_previous is not None:
                    prev, supply = self.market_previous
                    observed = max(0., supply + prev - units)
                    self.market_bound = observed if self.market_bound is None else .77*self.market_bound + .23*observed
                self.market_previous = units, lots[counter].quantity
            if self.cash_start <= 20000 and len(recipes)>1:
                top_goods = sorted(self.prior, key=lambda g:self.prior[g][1], reverse=True)[:2]
                coverage = min(sum(inv.get(g,0) for inv in s.public_inventories.values()) /
                               max(1.,self.demand[g]) for g in top_goods)
                winners = sum(c > 1.004*self.cash_start for c in s.public_capital.values())
                premium_stock = sum(sum(inv.get(g,0) for g in top_goods) for inv in s.public_inventories.values())
                evidence = self.market_bound if self.market_bound is not None else 0.
                if evidence < .27*len(s.public_capital) and coverage>=1.75 and winners<=2:
                    self.coast = True
                recovering = ((evidence > .38*len(s.public_capital) and winners >= 2 and coverage < 3.0) or winners >= max(4, ceil(.13*len(s.public_capital))) or
                              (premium_stock <= 5 and s.turn < 22))
                self.recovery = self.recovery+1 if recovering else 0
                if self.recovery >= 2:
                    self.coast = False
                halt_buying = s.turn <= 4 or self.coast
                if halt_buying and not any(s.inventory.values()):
                    return Decision()
        initial = 2.75 if crowd else 2.45
        if crowd and not self.last_asks and s.turn < 3:
            initial = 2.6
        reserve = {m:max(.001, l.reserve_price) for m,l in lots.items()}
        # The published large-field matches have two observed cash/horizon
        # pairs. Briefly run down stock near those horizons, then resume if the
        # actual match continues. Other market configurations stay adaptive.
        horizon = {12000.:40, 40000.:80}.get(self.cash_start) if crowd and "LAPTOP" in self.prior else None
        left = horizon - s.turn if horizon is not None else None
        wind_down = left is not None and 0 <= left <= 4
        asks = {}
        for g,(lo,hi) in self.prior.items():
            factor = self.price_factor[g]
            pressure = min(1., sum(min(8, inv.get(g,0)) for inv in s.public_inventories.values()) / max(1., 3*self.demand[g]))
            discount = 1.0 - 0.280*pressure
            if wind_down and s.inventory.get(g,0):
                discount *= .74 + .044*left
            asks[g] = tuple(round(p*factor*discount,3) for p in (lo,hi))
        self.cash_peak = max(self.cash_peak, s.capital)
        if self.narrow:
            name, recipe = next(iter(recipes.items()))
            if len(recipe.inputs) == 1:
                m, n = next(iter(recipe.inputs.items()))
                if m in lots:
                    # When demand exceeds supplier capacity, price the output
                    # to clear the lot and share its margin with the supplier.
                    stock = s.inventory.get("WIDGET",0)
                    factor = min(1., self.price_factor["WIDGET"]) if stock else min(1.,max(.95,self.price_factor["WIDGET"]))
                    ask = round(100.0 * factor, 3)
                    price = max(reserve[m], .431 * ask * 2 / n)
                    q = min(lots[m].quantity, int(.9 * s.capital/price))
                    if price * n >= .95*ask or stock > 2*self.demand["WIDGET"]:
                        q = 0
                    make = (s.inventory.get(m,0)+q)//n
                    self.last_asks = {"WIDGET":(ask,)}
                    self.quote = {}
                    self.last_bids = {(m,price):q} if q else {}
                    return Decision([Bid(m,q,price)] if q else [],[AssemblyOrder(name,make)],
                                    [Listing("WIDGET",stock+make,ask)])
        rates = {m:max(reserve[m],reserve[m]*self.ratios.get(m,initial)) for m in lots}
        limit = .84*s.capital
        if crowd:
            # Risk a bounded amount of seed capital and reinvest banked gains.
            floor = self.cash_start * 0.75 + .16*max(0., self.cash_peak-self.cash_start)
            limit = max(0.,min(.45*s.capital,s.capital-floor))
        if halt_buying:
            limit = 0.
        needed = defaultdict(int)
        made = defaultdict(int)
        cap = defaultdict(float)
        assembly = []
        options = []
        selected = {}
        for name,r in recipes.items():
            if any(m not in lots and s.inventory.get(m,0)<n for m,n in r.inputs.items()):
                continue
            g = r.output_good
            cost = sum(rates.get(m,0.) * n for m,n in r.inputs.items())
            if g not in selected or cost < selected[g][0]:
                selected[g] = cost,name,r
        for g,(cost,name,r) in selected.items():
            lo,hi = asks[g]
            realized = self.retail.get(g, .25*lo+.75*hi)
            value = .50*realized+.50*(.28*lo+.72*hi)
            v = self.demand[g]
            stock = s.inventory.get(g, 0)
            target = min(190,ceil(2.85*v+2.4*sqrt(v)+2))
            if wind_down:
                target = min(target, ceil(v * (.55+.30*left)))
            for i in range(max(0,target-stock)):
                coverage = (i+stock)/max(1.,v)
                score = value / (1.+0.22*coverage**1.8) - .36*cost
                options.append((score,name,value,i))
        # Spend against complete, feasible recipes, reusing owned inputs.
        # This budget includes all complements before another unit is funded.
        remaining = dict(s.inventory)
        last_name = None
        for score,name,value,_ in sorted(options,reverse=True):
            r = recipes[name]
            missing = {m:max(0,n-remaining.get(m,0)) for m,n in r.inputs.items()}
            spend = sum(n*rates.get(m,0.) for m,n in missing.items())
            if spend > limit or spend >= .86*value or (score < 0 and spend):
                continue
            if any(n and (m not in lots or n+needed[m]>lots[m].quantity) for m,n in missing.items()):
                continue
            limit -= spend
            made[r.output_good] += 1
            if last_name == name:
                old = assembly[-1]
                assembly[-1] = AssemblyOrder(name, old.quantity+1)
            else:
                assembly.append(AssemblyOrder(name,1))
                last_name = name
            other_cost = sum(n*rates.get(m,0.) for m,n in r.inputs.items())
            for m,n in r.inputs.items():
                needed[m] += missing[m]
                remaining[m] = remaining.get(m,0)+missing[m]-n
                cap[m] = max(cap[m],rates.get(m,0.)+(.85*value-other_cost)/n)
        self.quote = {}
        self.last_bids = {}
        bids = []
        for m,q in needed.items():
            if not q:
                continue
            top = min(cap[m], rates[m]*1.22)
            low = min(top, rates[m]*.77)
            premium = min(q,max(1,ceil(0.35*q)))
            levels = []
            for count,p in ((premium,top),(q-premium,low)):
                p = max(reserve[m],round(p,5))
                if count:
                    bids.append(Bid(m,count,p))
                    levels.append((p,p/reserve[m],count))
                    self.last_bids[m,p] = count
            self.quote[m] = levels
        listings = []
        self.last_asks = {}
        for g,(lo,hi) in asks.items():
            available = min(240, s.inventory.get(g,0)+made[g])
            if not available:
                continue
            # Interleave tiers so partial auction fills still reach premium buyers.
            for i in range(available):
                price = lo if (i%5 in (1,4)) else hi
                listings.append(Listing(g,1,price))
            if s.inventory.get(g,0)>available:
                listings.append(Listing(g,s.inventory[g]-available,lo))
            self.last_asks[g] = lo,hi
        return Decision(bids,assembly,listings)
